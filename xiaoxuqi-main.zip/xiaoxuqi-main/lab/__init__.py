"""Local training lab package."""
