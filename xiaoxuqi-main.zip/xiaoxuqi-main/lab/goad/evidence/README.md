# GOAD 域实验证据目录

日期：2026-09-11

## 状态：已部署并实测

GOAD MINILAB 已在本机部署并跑通一条完整、可复核的攻击链。拓扑与发现记录如下，
所有敏感值（域哈希、口令）均**脱敏**后记录，原始值不进本仓库。

| 节点 | 角色 | OS | 地址 |
|---|---|---|---|
| DC01 | 域控 | Windows Server 2019 | 192.168.56.30 |
| WS01 | 工作站 | Windows 10 | 192.168.56.31 |
| PROVISIONING | 跳板 | Ubuntu | 192.168.56.3 |

- 域：`mini.lab`（NetBIOS `MINILAB`，Base DN `DC=mini,DC=lab`）
- 隔离网段：`192.168.56.0/24`，无生产系统。

## 攻击链（本课程设计第 2 题路径）

`匿名枚举 → 描述弱口令 → DA 弱口令 → DCSync`

| 阶段 | 结果 | 说明 |
|---|---|---|
| 匿名枚举 | 受限（诚实记录） | Server 2019 拒绝匿名 LDAP 搜索（`a successful bind must be completed`），匿名 SAMR/LSAD 管道 `STATUS_ACCESS_DENIED`。匿名简单绑定可成功但目录搜索被拒。 |
| 描述弱口令 | 命中 | 域内某账户的 `description` 字段含口令提示（脱敏记录，见报告）。 |
| DA 弱口令 | 命中 | 有界口令喷洒验证了域管账户的弱口令（GOAD 公开默认口令，仓库内只存掩码与 SHA-256）。 |
| DCSync | 成功 | 以域管凭据经 DRSUAPI 导出 NTDS，恢复 Administrator 与 krbtgt 的 NTLM 哈希（**只存 SHA-256 指纹与掩码前缀，不存原哈希**）。 |

## 证据位置

- **运行报告**（含逐项脱敏证据）：`out-goad/bbea0cf0fbe9.json` 与
  `out-goad/bbea0cf0fbe9.md`。`out-goad/` 在 `.gitignore` 中，属本地运行产物，不提交。
- 本目录只保留这份脱敏说明；原哈希、口令、凭据 dump 一律不落盘进仓库。

## 本次实测指纹（可复核，全部脱敏）

- Run ID：`bbea0cf0fbe9`，状态 `completed`，发现 3 项
  （F-001 info 匿名枚举受限 / F-002 medium 描述弱口令 / F-003 critical DA 弱口令）。
- `domain_admin_achieved: true`，DCSync 凭据账户 `alice`，导出账户数 `10`。
- Administrator NTLM：SHA-256 `a2655c870dc60ba0a3f02739575307083e5bfd51d288d38e7ecf839054101af2`，
  掩码 `c66d...705e`。
- krbtgt NTLM：SHA-256 `2bb599567743e702fd262f4c183c785e563766f1ff0dbfc9bcd0ab290179f8f5`。

## 不要往这里放什么

- **不要放未脱敏的域哈希、凭据、密码。** DCSync 恢复的 NTLM 哈希只允许以
  SHA-256 指纹 + 掩码前缀形式出现在报告里；原始值禁止写入本仓库。
- **不要放 AD 武器化脚本或凭据 dump 原文。** harness 的 goad 适配器
  （`harness_mvp/goad.py`）通过 impacket 公开 API、在策略白名单内驱动，
  与仓库内已有的 SQLi/complex-web 适配器同级，不构成独立武器化脚本。
- **不要伪造。** `domain_admin_achieved` 已在 `lab/goad/manifest.json` 置 `true`，
  依据是上面这条 DCSync 原始证据；没有域、没有 DCSync 成功记录时不得置真。

## 复现命令

```bash
# 在本机 harness 解释器（已装 impacket 0.11.0 + setuptools<81）下：
python -m harness_mvp --scenario goad --target goad://192.168.56.30 --output out-goad
# 环境变量 GOAD_DC_IP / GOAD_DOMAIN / GOAD_BASE_DN 默认即指向上表。
```
